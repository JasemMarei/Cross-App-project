import * as React from 'react';
import { View, Text,StyleSheet,Button } from 'react-native';

export default function UpdateCategory({navigation}) {

    return (
        <View style={{flex:1,alignContent:"center",justifyContent:"center"}}>
            <Text>Update Category Here</Text>
        </View>
    );
}