# Course-Project
The purpose of the project is to fetch and display data from a public ecommerce API.  React Native router to navigate multiple pages and created a forms to post data
